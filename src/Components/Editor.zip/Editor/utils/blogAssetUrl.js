import axios from "../../../api/axios";

/**
 * API returns storage paths such as /file-storage/blog/....
 * Keep those relative paths in Slate JSON (the backend needs them to
 * identify temporary uploads), but render them against the API host.
 */
export const resolveBlogAssetUrl = (url) => {
  if (typeof url !== "string" || !url) return "";
  if (/^(https?:|blob:|data:)/i.test(url)) return url;

  const baseURL = axios.defaults?.baseURL;
  if (!baseURL) return url;

  try {
    const apiBase = new URL(baseURL, window.location.origin);
    return new URL(url, apiBase.origin).toString();
  } catch {
    return url;
  }
};
